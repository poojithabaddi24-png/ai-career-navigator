"""LLM factory. Set LLM_PROVIDER to groq (free-tier API), anthropic, or openai."""
import os
from dotenv import load_dotenv

load_dotenv()


def get_llm(temperature: float = 0.3):
    provider = os.getenv("LLM_PROVIDER", "groq").lower()

    if provider == "groq":
        # Groq exposes an OpenAI-compatible API. Free-tier usage is rate-limited;
        # do not add a billing method or upgrade if you want to keep usage at $0.
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(
            model=os.getenv("GROQ_MODEL", "openai/gpt-oss-20b"),
            base_url="https://api.groq.com/openai/v1",
            api_key=os.getenv("GROQ_API_KEY"),
            temperature=temperature,
        )

    if provider == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"), temperature=temperature)

    if provider == "anthropic":
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(
            model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
            temperature=temperature,
            max_tokens=2000,
        )

    raise ValueError(
        f"Unsupported LLM_PROVIDER={provider!r}. Choose 'groq', 'openai', or 'anthropic'."
    )
