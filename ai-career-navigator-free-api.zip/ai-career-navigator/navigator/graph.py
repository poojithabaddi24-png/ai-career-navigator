"""
Multi-agent career navigator built with LangGraph.

Flow:
  profile_analyst -> career_explorer -> skill_gap_analyst
                                          |-> roadmap_planner --|
                                          |-> interview_coach --|-> report_compiler -> END
(roadmap_planner and interview_coach run in parallel.)
"""
from typing import TypedDict, List
from pydantic import BaseModel, Field
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.graph import StateGraph, START, END

from .llm import get_llm


# ---------- Shared state ----------
class CareerState(TypedDict, total=False):
    # inputs
    resume_text: str
    interests: str
    target_role: str          # optional; empty -> use top recommendation
    hours_per_week: int
    # agent outputs
    profile_summary: str
    recommended_roles: List[dict]
    chosen_role: str
    skill_gap: str
    roadmap: str
    interview_prep: str
    final_report: str


class RoleRec(BaseModel):
    title: str
    fit_score: int = Field(description="0-100 fit with the person's profile")
    why: str = Field(description="1-2 sentence justification")
    typical_salary_range: str = Field(description="Approximate range, state currency and region")


class RoleList(BaseModel):
    roles: List[RoleRec] = Field(description="Exactly 4 roles, best fit first")


def _ask(system: str, user: str, temperature: float = 0.3) -> str:
    resp = get_llm(temperature).invoke([SystemMessage(content=system), HumanMessage(content=user)])
    return resp.content if isinstance(resp.content, str) else "".join(
        b.get("text", "") for b in resp.content if isinstance(b, dict)
    )


# ---------- Agents (graph nodes) ----------
def profile_analyst(state: CareerState) -> dict:
    out = _ask(
        "You are a career profile analyst. Extract from the resume: current level, core skills, "
        "tools, domains, achievements, and gaps. Be concise, use bullet points.",
        f"RESUME:\n{state['resume_text']}\n\nINTERESTS:\n{state.get('interests', 'not given')}",
    )
    return {"profile_summary": out}


def career_explorer(state: CareerState) -> dict:
    llm = get_llm(0.4).with_structured_output(RoleList)
    result = llm.invoke([
        SystemMessage(content="You are a career strategist. Recommend realistic roles matching the profile "
                              "and interests. Be honest about fit; do not inflate scores."),
        HumanMessage(content=f"PROFILE:\n{state['profile_summary']}\n\nINTERESTS:\n{state.get('interests', '')}"),
    ])
    roles = [r.model_dump() for r in result.roles]
    chosen = state.get("target_role", "").strip() or roles[0]["title"]
    return {"recommended_roles": roles, "chosen_role": chosen}


def skill_gap_analyst(state: CareerState) -> dict:
    out = _ask(
        "You are a skill gap analyst. Compare the person's profile with what the target role typically "
        "requires. Output three sections in markdown: 'Strengths you already have', "
        "'Missing skills (ranked by importance)', 'Quick wins (under 4 weeks)'.",
        f"TARGET ROLE: {state['chosen_role']}\n\nPROFILE:\n{state['profile_summary']}",
    )
    return {"skill_gap": out}


def roadmap_planner(state: CareerState) -> dict:
    hrs = state.get("hours_per_week", 8)
    out = _ask(
        "You are a learning-path designer. Build a 12-week roadmap in markdown, week-by-week, "
        "with concrete topics, free or well-known resources, and one portfolio project milestone "
        "every 3-4 weeks. Respect the weekly time budget.",
        f"TARGET ROLE: {state['chosen_role']}\nHOURS/WEEK: {hrs}\n\nSKILL GAPS:\n{state['skill_gap']}",
        temperature=0.4,
    )
    return {"roadmap": out}


def interview_coach(state: CareerState) -> dict:
    out = _ask(
        "You are an interview and resume coach. Give: (1) 5 resume bullet improvements tailored to the "
        "target role, (2) 8 likely interview questions mixing technical and behavioral, each with a "
        "one-line tip on what a strong answer includes. Use markdown.",
        f"TARGET ROLE: {state['chosen_role']}\n\nPROFILE:\n{state['profile_summary']}\n\n"
        f"SKILL GAPS:\n{state['skill_gap']}",
    )
    return {"interview_prep": out}


def report_compiler(state: CareerState) -> dict:
    roles_md = "\n".join(
        f"- **{r['title']}** (fit {r['fit_score']}/100) - {r['why']} _Salary: {r['typical_salary_range']}_"
        for r in state["recommended_roles"]
    )
    report = f"""# Your Career Navigator Report

## 1. Profile Summary
{state['profile_summary']}

## 2. Recommended Roles
{roles_md}

**Focus role:** {state['chosen_role']}

## 3. Skill Gap Analysis
{state['skill_gap']}

## 4. 12-Week Roadmap
{state['roadmap']}

## 5. Resume & Interview Prep
{state['interview_prep']}

---
_AI-generated guidance. Salary figures and requirements are estimates; verify with current job postings._
"""
    return {"final_report": report}


# ---------- Graph ----------
def build_graph():
    g = StateGraph(CareerState)
    g.add_node("profile_analyst", profile_analyst)
    g.add_node("career_explorer", career_explorer)
    g.add_node("skill_gap_analyst", skill_gap_analyst)
    g.add_node("roadmap_planner", roadmap_planner)
    g.add_node("interview_coach", interview_coach)
    g.add_node("report_compiler", report_compiler)

    g.add_edge(START, "profile_analyst")
    g.add_edge("profile_analyst", "career_explorer")
    g.add_edge("career_explorer", "skill_gap_analyst")
    # parallel fan-out
    g.add_edge("skill_gap_analyst", "roadmap_planner")
    g.add_edge("skill_gap_analyst", "interview_coach")
    # join
    g.add_edge(["roadmap_planner", "interview_coach"], "report_compiler")
    g.add_edge("report_compiler", END)
    return g.compile()
