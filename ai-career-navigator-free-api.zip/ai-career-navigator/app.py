import io
import streamlit as st
from pypdf import PdfReader
from navigator.graph import build_graph

st.set_page_config(page_title="AI Career Navigator", page_icon="🧭", layout="wide")
st.title("🧭 AI Career Navigator")
st.caption("A LangGraph multi-agent system: profile analyst → career explorer → skill gap → roadmap + interview coach")


@st.cache_resource
def get_app():
    return build_graph()


with st.sidebar:
    st.header("Your details")
    upload = st.file_uploader("Upload resume (PDF or TXT)", type=["pdf", "txt"])
    pasted = st.text_area("...or paste resume text", height=180)
    interests = st.text_area("Interests / goals", placeholder="e.g. I like data, building products, remote work")
    target = st.text_input("Target role (optional)", placeholder="Leave empty to let the AI choose")
    hours = st.slider("Study hours per week", 2, 40, 8)
    run = st.button("Generate my career plan", type="primary", use_container_width=True)


def read_resume() -> str:
    if upload is not None:
        if upload.name.lower().endswith(".pdf"):
            reader = PdfReader(io.BytesIO(upload.read()))
            return "\n".join(p.extract_text() or "" for p in reader.pages)
        return upload.read().decode("utf-8", errors="ignore")
    return pasted


if run:
    resume = read_resume().strip()
    if len(resume) < 50:
        st.error("Please upload or paste a resume (at least a few lines).")
        st.stop()

    steps = {
        "profile_analyst": "Analyzing your profile",
        "career_explorer": "Exploring career options",
        "skill_gap_analyst": "Finding skill gaps",
        "roadmap_planner": "Building your roadmap",
        "interview_coach": "Preparing interview coaching",
        "report_compiler": "Compiling report",
    }
    state = {"resume_text": resume, "interests": interests, "target_role": target, "hours_per_week": hours}
    final = {}
    with st.status("Agents are working...", expanded=True) as status:
        try:
            for update in get_app().stream(state, stream_mode="updates"):
                for node, out in update.items():
                    st.write(f"✅ {steps.get(node, node)}")
                    final.update(out)
            status.update(label="Done!", state="complete")
        except Exception as e:
            status.update(label="Failed", state="error")
            st.error(f"Error: {e}")
            st.stop()

    report = final["final_report"]
    tabs = st.tabs(["Full report", "Roles", "Roadmap", "Interview prep"])
    with tabs[0]:
        st.markdown(report)
        st.download_button("Download report (.md)", report, "career_report.md")
    with tabs[1]:
        for r in final["recommended_roles"]:
            st.subheader(f"{r['title']}  ·  {r['fit_score']}/100")
            st.progress(r["fit_score"] / 100)
            st.write(r["why"])
            st.caption(r["typical_salary_range"])
    with tabs[2]:
        st.markdown(final["roadmap"])
    with tabs[3]:
        st.markdown(final["interview_prep"])
else:
    st.info("Add your resume in the sidebar and click **Generate my career plan**.")
