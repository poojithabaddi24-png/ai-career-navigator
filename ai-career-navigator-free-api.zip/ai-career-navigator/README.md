# 🧭 AI Career Navigator (LangGraph Multi-Agent)

Upload a resume → get role recommendations, skill gaps, a 12-week roadmap, and interview prep.

## Agents
| Agent | Job |
|---|---|
| Profile Analyst | Extracts skills, level, achievements from resume |
| Career Explorer | Recommends 4 roles with fit score + salary range (structured output) |
| Skill Gap Analyst | Compares profile vs. target role |
| Roadmap Planner | 12-week learning plan (runs in parallel) |
| Interview Coach | Resume bullets + interview Qs (runs in parallel) |
| Report Compiler | Joins everything into one report |

## Run locally (free-tier Groq API)

1. Create an API key at https://console.groq.com/keys while staying on the Free plan.
2. Install Python dependencies:
   ```bash
   python -m venv .venv
   # Windows PowerShell: .venv\Scripts\Activate.ps1
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   ```
3. Copy `.env.example` to `.env` and set `GROQ_API_KEY` to your key.
4. Run `streamlit run app.py`.

The default provider is Groq using its OpenAI-compatible API and the `openai/gpt-oss-20b` model. Free usage has limits and can return a rate-limit error when exhausted. To avoid charges, do not add a payment method or upgrade to a paid tier. Free quotas and model availability can change.

## Deploy (free hosting)

1. Push the contents of this folder to a GitHub repository. Do not commit `.env` or any API key.
2. Go to https://share.streamlit.io/ and create an app connected to that repository. Main file: `app.py`.
3. In Streamlit app settings, open **Secrets** and add:
   ```toml
   LLM_PROVIDER = "groq"
   GROQ_API_KEY = "paste-your-Groq-key-here"
   GROQ_MODEL = "openai/gpt-oss-20b"
   ```
4. Deploy. Streamlit hosting has a free option; usage and resource limits apply.

If the model ID is unavailable in your Groq account, check https://console.groq.com/docs/models and select a currently available model that supports tool/function calling, because the career explorer uses structured output.

## Extend it
- Add a job-search agent using a web search tool (Tavily/SerpAPI) in `graph.py`.
- Add memory with LangGraph checkpointers (`SqliteSaver`) to save user sessions.
- Add a supervisor node with conditional edges to route follow-up questions.
